const SUBJECTS = ["Languages", "Sciences", "Arts", "Sports"];
const HOURS_PER_DAY = 6;
const DAYS_PER_WEEK = 5;

function generate() {
  let timetable = Array(DAYS_PER_WEEK)
    .fill()
    .map(() => Array(HOURS_PER_DAY).fill(null));
  let subjectHours = { Languages: 10, Sciences: 10, Arts: 5, Sports: 5 };

  for (let day = 0; day < DAYS_PER_WEEK; day++) {
    for (let hour = 0; hour < HOURS_PER_DAY; hour++) {
      let availableSubjects = SUBJECTS.filter(
        (subject) => subjectHours[subject] > 0
      );
      if (availableSubjects.length > 0) {
        let subject =
          availableSubjects[
            Math.floor(Math.random() * availableSubjects.length)
          ];
        timetable[day][hour] = subject;
        subjectHours[subject]--;
      }
    }
  }

  return timetable;
}

function validateConstraints(timetable) {
  let subjectHours = { Languages: 0, Sciences: 0, Arts: 0, Sports: 0 };

  for (let day of timetable) {
    for (let subject of day) {
      if (subject in subjectHours) {
        subjectHours[subject]++;
      }
    }
  }

  return (
    subjectHours["Languages"] === 10 &&
    subjectHours["Sciences"] === 10 &&
    subjectHours["Arts"] === 5 &&
    subjectHours["Sports"] === 5
  );
}

module.exports = { generate, validateConstraints };
